package com.mycompany.geometrie.frontend.controller;

import com.mycompany.geometrie.backend.entity.Carre;
import com.mycompany.geometrie.backend.entity.Rectangle;
import com.mycompany.geometrie.backend.entity.TriangleRectangle;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "OperationServlet", urlPatterns = "/operation-servlet")
public class OperationController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        HttpSession session = req.getSession();

        RequestDispatcher requestDispatcher;

        String operation = req.getParameter("operation");
        String figure = req.getParameter("figure");


        switch (operation) {
            case ("surface"):
                session.setAttribute("surface", operation);
                session.setAttribute("figure", figure);
                if (figure.equals("carre")) {
                    double cote = Double.parseDouble(req.getParameter("cote"));

                    session.setAttribute("cote", cote);
                    Carre carre = new Carre(cote);

                    session.setAttribute("surface", carre.calculerSurface());

                    requestDispatcher = req.getRequestDispatcher("/affich-result.jsp");
                    requestDispatcher.forward(req, resp);
                } else if (figure.equals ("rectangle")) {
                    double longueur = Double.parseDouble(req.getParameter("longueur"));
                    double largeur = Double.parseDouble(req.getParameter("largeur"));

                    session.setAttribute("longueur", longueur);
                    session.setAttribute("largeur", largeur);
                    Rectangle rectangle = new Rectangle(longueur, largeur);


                    session.setAttribute("surface", rectangle.calculerSurface());

                    requestDispatcher = req.getRequestDispatcher("/affich-result.jsp");
                    requestDispatcher.forward(req, resp);

                } else if (figure.equals(("trianglerectangle"))) {
                    double base = Double.parseDouble("base");
                    double hauteur = Double.parseDouble(req.getParameter("hauteur"));
                    double hypotenuse = Double.parseDouble(req.getParameter("hypotenuse"));
                    session.setAttribute("base", base);
                    session.setAttribute("hauteur", hauteur);
                    session.setAttribute("hypotenuse", hypotenuse);
                    TriangleRectangle triangleRectangle = new TriangleRectangle(base, hauteur, hypotenuse);

                    session.setAttribute("surface", triangleRectangle.calculerSurface());
                    requestDispatcher = req.getRequestDispatcher("/affich-result.jsp");
                    requestDispatcher.forward(req, resp);

                } else {
                    out.println("Coucou" + figure);
                }

                break;
            case ("perimetre"):
                session.setAttribute("perimetre", operation);
                session.setAttribute("figure", figure);
                if (figure.equals("carre")) {
                    double cote = Double.parseDouble((req.getParameter("cote")));
                    session.setAttribute("cote", cote);
                    Carre carre = new Carre(cote);

                    session.setAttribute("perimetre", carre.calculerPerimetre());

                    requestDispatcher = req.getRequestDispatcher("/affich-result.jsp");
                    requestDispatcher.forward(req, resp);

                } else if (figure == ("rectangle")) {
                    double longueur = Double.parseDouble((req.getParameter("longueur")));
                    double largeur = Double.parseDouble((req.getParameter("largeur")));
                    session.setAttribute("longueur", longueur);
                    session.setAttribute("largeur", largeur);
                    Rectangle rectangle = new Rectangle(longueur, largeur);

                    session.setAttribute("perimetre", rectangle.calculerPerimetre());

                    requestDispatcher = req.getRequestDispatcher("/affich-result.jsp");
                    requestDispatcher.forward(req, resp);

                } else if (figure.equals(("trianglerectangle"))) {
                    double base = Double.parseDouble("base");
                    double hauteur = Double.parseDouble(req.getParameter("hauteur"));
                    double hypotenuse = Double.parseDouble(req.getParameter("hypotenuse"));
                    session.setAttribute("base", base);
                    session.setAttribute("hauteur", hauteur);
                    session.setAttribute("hypotenuse", hypotenuse);
                    TriangleRectangle triangleRectangle = new TriangleRectangle(base, hauteur, hypotenuse);

                    session.setAttribute("perimetre", triangleRectangle.calculerPerimetre());

                    requestDispatcher = req.getRequestDispatcher("/affich-result.jsp");
                    requestDispatcher.forward(req, resp);

                } else {
                    out.println("Coucou Perimetre" + figure);
                }

                break;

            default:
                out.println("Probleme operation controller");

        }


    }
}
