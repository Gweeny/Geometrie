package com.mycompany.geometrie.frontend.controller;

import com.mycompany.geometrie.backend.entity.Carre;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "MainController", urlPatterns = "/main-controller")
public class MainController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        HttpSession session = req.getSession();

        RequestDispatcher requestDispatcher;

        String figure = req.getParameter("figure");

        if (figure.equals("carre")){
            session.setAttribute("figure",figure);
            requestDispatcher = req.getRequestDispatcher("/case-carre.jsp");
            requestDispatcher.forward(req, resp);
        }else if (figure.equals("rectangle")){
            session.setAttribute("figure",figure);
            requestDispatcher = req.getRequestDispatcher("/case-rectangle.jsp");
            requestDispatcher.forward(req, resp);
        }
        else out.println("bordel" + figure);

        /*switch (figure){
            case ("carre"):
                session.setAttribute("figure",figure);
                requestDispatcher = req.getRequestDispatcher("/case-carre.jsp");
                requestDispatcher.forward(req, resp);
            case ("rectangle"):
                session.setAttribute("figure",figure);
                requestDispatcher = req.getRequestDispatcher("/case-rectangle.jsp");
                requestDispatcher.forward(req, resp);
            case("TriangleRectangle"):
                session.setAttribute("figure",figure);
                requestDispatcher = req.getRequestDispatcher("/case-triangle-rectangle");
                requestDispatcher.forward(req, resp);

            default:
                out.println("Problem Main Controller");

        }*/

        }

}
